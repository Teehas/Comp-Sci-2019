<?php
$b= 1;
$n= 1;
$y= 1;
$T= 10;
$x= 0;
$g= 0;
$a= 0;
$count=0;
if (($b<0 or $b>100) or ($n<0 or $n>100) or ($y<0 or $y>100) or ($T<0 or $T>100)) 
{
    echo "inputs must be integer values between 0 and 100";
    exit; 
}
for ($x=0; $x*$b+$g*$n+$a*$y<=$T; $x++)
{
    for($g=0; $x*$b+$g*$n+$a*$y<=$T;$g++) 
    {
        for ($a=0; $x*$b+$g*$n+$a*$y<=$T; $a++)
        {
            if ($x*$b+$g*$n+$a*$y > 0) 
            {
                ++$count;
                echo "$x brown trout, $g northern pike, $a yellow pickerel";
                echo "\n";
            }
        }
        $a=0;
    }
    $g=0;
}
echo "$count number of ways to catch a fish";