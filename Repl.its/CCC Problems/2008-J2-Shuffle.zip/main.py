play_list = ["A","B","C","D","E"]
b_input = (input("welcome, Enter number b1, b2, or b3 to begin"))

while (b_input == True):
  if (b_input == "b1"):
    button_1()
  elif (b_input == "b2"):
    button_2()
  elif (b_input == "b3"):
    button_3()
  elif (b_input == "b4"):
    

    def button_1():
      number_of_press = int(input("Enter number of presses"))
      for i in range(number_of_press):
        temp = play_list[0]
        for i in range(10):
          play_list[i] = play_list[i+1]
      #print(i)
        play_list[4] = temp
      print(play_list)
      #call the button_1 function above
      button_1()

def button_2():
 number_of_press = int(input("Enter number of presses"))
 for i in range(number_of_press):
  temp = play_list[0]
  for i in range(10):
    play_list[i] = play_list[i-1]
 #print(i)
  play_list[0] = temp
 print(play_list)
#call the button_1 function above
button_2()