#x = ['-', '-', '3', '+', '2', '1', '9']
#x = ['+','2','-','2','1']
x = [['+','2','p'], ['-','2','1']]
x = {}

#print(x)
for i in range(len(x)):
  if (x[1][0] == '+' or x[1][0] == '-'):
    x.insert(-1, x[0])
    x.pop(0)
#print([0][1])
x.remove('p')
x.insert(([0][-1]), x[1])

print(x)