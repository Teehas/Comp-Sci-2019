#--------------------------S1-------------------------------

"""
N = int(input())
swifts = []
semaphores = []
x = 0
y = 0
for i in range(N):
  d = int(input())
  swifts.append(d)
for k in range(N):
  d = int(input())
  semaphores.append(d)
for z in range(N):

  for q in range(z):
    x = swifts[q]
    if (z>0):
      x = swifts[q]+swifts[q-1]
  for w in range(z):
    y = semaphores[w]
    if (z>0):
      y = semaphores[w]+semaphores[w-1]


if x == y: print(z)
else: print('0')
"""

#-----------------------------S2-----------------------------

initial = []
final = []
N = int(input())

for i in range(N):
  d = int(input())
  initial.append(d)

initial.sort()
b = -1
for x in range(N):
  if len(initial)>0:
    final.append(initial[-1])
    final.append(initial[0])
    initial.pop(0)
    initial.pop()
    b = b-1
  else: break

final.reverse()
print(final)
