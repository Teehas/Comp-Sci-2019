w = 200
h = 5
if ((w/h*h) > 25):
  print ("Overweight")
elif ((w/h*h) > 18.5 and(w/h*h) <= 25 ):
  print("Normal weight")
elif(((w/h*h) < 18.5)):
  print ("underweight")