#FRACTION REDUCER!!!!!
from math import gcd
num = int(input("please enter a possitive intager for the numarator"))
den = int(input("please enter a possitive intager for the denominator"))
x = 0
y = 0
#determining the mixed number if any
if (num % den > 0): 
  x = num % den
  num = num // den

else: pass
# reducing the remaining fraction using gcd function from math library
y = gcd(num, den)
num = num / y
den = den / y
(print("Reduced fraction:", x, num, "/", den ))