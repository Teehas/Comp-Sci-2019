import sys

print("HELLO MANDEMMM")
#print("enter an x coordinate")
x_coord = int(input("enter an x coordinate\n"))
y_coord = int(input("enter an y coordinate\n"))
print("(",x_coord,",", y_coord,")")
if (x_coord > 0 and y_coord > 0):
  print ("Q1")
if (x_coord < 0 and y_coord > 0):
  print ("Q2")
if (x_coord < 0 and y_coord < 0):
  print ("Q3")
if (x_coord > 0 and y_coord < 0):
  print ("Q4")
else: print("origin of axis")
print (sys.version)