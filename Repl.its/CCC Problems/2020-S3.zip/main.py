from itertools import permutations
n = input("enter value for n")
h = input("enter value for h")
count = 0
perms = [''.join(x) for x in permutations(n)]
for y in perms: 
  if (y in h): count = count+1
print('There are', count, 'permutations of', n, 'in', h)