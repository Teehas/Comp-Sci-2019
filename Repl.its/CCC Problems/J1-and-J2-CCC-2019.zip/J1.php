<?php
//Tejas Soni, 2019-09-18
//Problem J1: Speed fines are not fine!

$v = "input speed here";
$l = "input limit here";

if ($v < 0 || $l < 0) {
    print " Error, speed limit and the speed of the car must be positive";
    exit;
}
if (!is_int ($v) || !is_int ($l) ) {
    print " Error, speed limit and the cars speed must be an integer";
    exit;
}

$f_1 = "100 dollars";
$f_2 = "270 dollars";
$f_3 = "500 dollars";

if ($v <= $l) {
    print "Congratulations, you are within the speed limit!";
} elseif ($v > $l and $v <= $l + 20) {
    print "You are speeding and your fine is $f_1 ";
} elseif ($v >= $l + 21 and $v <= $l + 30) {
    print "You are speeding and your fine is $f_2";
} elseif ($v >= $l + 31 )
    print "You are speeding and your fine is $f_3";


?>

