<?php
//Tejas Soni, 2019-09-18
//Problem J2: Sounds fishy!

$i_1 = "integer 1";
$i_2 = "integer 2";
$i_3 = "integer 3";
$i_4 = "integer 4";

if (!is_int ($i_1) || !is_int ($i_2) || !is_int ($i_3) || !is_int ($i_4) ) {
    print " Error, Depth input must be an integer.";
}

elseif ($i_1 < $i_2 and $i_2 < $i_3 and $i_3 < $i_4); {
    print "Fish Rising.";
}
elseif ($i_1 > $i_2 and $i_2 > $i_3 and $i_3 > $i_4); {
    print "Fish Diving.";
}
elseif ($i_1 = $i_2 and $i_2 = $i_3 and $i_3 = $i_4); {
    print "Fish At Constant Depth.";
}

else {
   print "No Fish.";
}

?>
