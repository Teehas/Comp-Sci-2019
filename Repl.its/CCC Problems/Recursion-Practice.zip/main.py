"""
#1
def func(x):
  if (x==1):
    return 1 
    
  else:
    return (x+func(x-1))

print (func(1))
"""
"""
#2
def fib(x):
  if (x == 1 or x == 2):
    return 1
  else:
    return fib(x-1)+fib(x-2)

print (fib(40))
"""
"""
#3
def dig(n):
  #n=int(n)
  if (n<10):
    return 1
  else:
    return 1 + dig(n/10)

print(dig(18340123))
"""
"""
def func(n):
  if (n==1):
    return 3
  else:
    return 3+(func(n-1))

print (func(3))
"""
"""
def func(n):
  if (n==1):
    return 1
  else:
    return n+(func(n-1))

print (func(5))
"""
"""
def n(word:str):
  if (len(word) == 0):
    return
  else:
    print(word[0])
    n(word[1:])

n("hello")
"""
def srev(word:str):
  if 