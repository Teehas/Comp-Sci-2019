p = int(input("please enter a cost for the pink ticket"))
g = int(input("please enter a cost for the green ticket"))
r = int(input("please enter a cost for the red ticket"))
o = int(input("please enter a cost for the orange ticket"))
total = int(input("please enter the total number of dollars you would like to raise as a positive intager value"))

count = 0
t_list = []
for a in range((total//p) + 1):
  for b in range((total//g) + 1):
    for c in range((total//r) + 1):
      for d in range((total//o) + 1):
        if ((a * p) + (b * g) + (c * r) + (d * o) == total):
          print ('pink', a, 'green',b, 'red', c, 'orange' , d)
          count += 1
          if a > 0: t_list.append(a)
          if b > 0: t_list.append(b)         
          if c > 0: t_list.append(c)
          if d > 0: t_list.append(d)
print('the total number of possibilities is', count)
print('The minimum tickets to print would be', t_list[0])