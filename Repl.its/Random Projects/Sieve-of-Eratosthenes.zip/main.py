def sieve(n):
  l = []
  x = 1
  for i in range(n):
    l.append(x)
    x = x+1
  for y in range(len(l)):
    z = l[0]
    if ((z % 2) != 0):
      l.remove(z)
      z = z+1
      print(l)

sieve(10)