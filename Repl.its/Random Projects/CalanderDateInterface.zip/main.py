
import datetime

class Calendar:

  def __init__(self, day, month, year):
    self.day = day
    self.month = month
    self.year = year
    months1 = [1,3,5,7,8,10,12]
    months2 = [4,6,9,11]
    if (month > 12 or month < 1): 
      self.month = 1
      self.year = 2012
      self.day = 1
    if (year < 1 or year > 9999): 
      self.month = 1
      self.year = 2012
      self.day = 1
    if (day < 1):
      self.month = 1
      self.year = 2012
      self.day = 1
    if (month in months1 and day > 31):
      self.month = 1
      self.year = 2012
      self.day = 1
    if (month in months2 and day > 30):
      self.month = 1
      self.year = 2012
      self.day = 1
    if (month == 2):
      if(year % 4 == 0 and year % 100 != 0):
        if (day > 29):
          self.month = 1
          self.year = 2012
          self.day = 1
      if(year % 400 == 0):
        if (day > 29):
          self.month = 1
          self.year = 2012
          self.day = 1
      elif(day > 28):
        self.month = 1
        self.year = 2012
        self.day = 1

  def last_date(self):
    try:
      last_date = datetime.date(self.year, self.month, self.day) - datetime.timedelta(days=1)
      print ('Previous Date: ' + str(last_date))
    except (TypeError):
      print("year, month and day must be entered as integers")
    except(ImportError):
      print("Datetime module can not be imported, either use a different IDE or reinstall python")
#    except(SyntaxError):
#      print("year, month and day must be entered as integers")

  def next_date(self):
    try:
      next_date = datetime.date(self.year, self.month, self.day) + datetime.timedelta(days=1)
      print ('Next Date: ' + str(next_date))
    except (TypeError):
      print("year, month and day must be entered as integers")
    except(ImportError):
      print("Datetime module can not be imported, either use a different IDE or reinstall python")

  def dotw(self):
    try:
      dotw = datetime.date(self.year, self.month, self.day).weekday()
      days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
      print("The day of the week is", days[dotw])
    except (TypeError):
      print("year, month and day must be entered as integers")
    except(ImportError):
      print("Datetime module can not be imported, either use a different IDE or reinstall python")



#This code relies on the datetime module which makes dates into their own datatype (as objects)so they can be worked with in a similar form to integers. 
class interface:
#The Calendar class is initialized with the variables day, month, year and num (num is used to select which method is called - 1 for last_date, 2 for next_date and 3 for dotw). The date is then error checked to ensure it is a valid date on the calander with a special check for leap year dates and months with 30 vs 31 days as well. If the date is invalid, the fallback date of 1, 1, 2012 is used.
  
  def __init__(self, d, m, y, num):
    self.d = d
    self.m = m
    self.y = y
    self.num = num

    x = Calendar(self.d, self.m, self.y)

    #Date inputted is equal to self. year month and day. last_date is set as the current date (as an integer value) minus one day which is obtained through the timedelta (day = 1) method. the value is then outputted.
    if (self.num == 1): x.last_date()

    #next_date is obtained through much the same method as last_date however timedelta(day = 1) is added to the current date instead of subtracted.
    elif (self.num == 2): x.next_date()

    #The .weekday() method assigns an integer value for the day of the week based on the inputted date from 0 for monday and 6 for sunday. The integer is recorded and assigned to a list of the days of the week, which is then outputted
    elif(self.num == 3): x.dotw()

#The exceptions I have chosen to catch are for in case of non integer values that could accidentally be entered like float values. Unfortunately this does not catch for strings as that would be a syntax error and not a TypeError. The second exception is in case the datetime module can not be imported which is a very common error when using IDEs.

#driver code
#i = interface(1,1,2012,1)

class testing:
  def __init__(self, d1, m1, y1):
    self.d1 = d1
    self.m1 = m1
    self.y1 = y1

  def tst(self):  
    x = Calendar(self.d1, self.m1, self.y1) 
    x.last_date()
    x.next_date()
    x.dotw()
test1 = testing(1,0,2020)
test1.tst()
test2 = testing(4,11,2019)
test2.tst()
test3 = testing(16,2.123,2003.2)
test3.tst()