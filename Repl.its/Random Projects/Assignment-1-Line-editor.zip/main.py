def line_editor():
  i = 0
  master_line = []
  total_inputs = []
  deletedwords = []
  while True:
    c = print(input(str("Enter a word or command")))
    if (c == "d"):
      i = input(int("which word would you like to remove"))+1
      deletedwords.append(master_line[-1])
      total_inputs.append("d")
      master_line.remove[i]
    elif (c=="undo"):
      q = total_inputs[-1]
      while True:
        total_inputs.append("undo")
        if (q == "redo"):
          k = 1
          p = 0
          while True:
            if total_inputs[-k] == "undo" or "redo":
              k = k+1
              continue
            else: 
              p = total_inputs[-k]
              q = 0
              False
        elif (q or p == "d"):
          master_line.append(deletedwords[-1])[-1]
          False
        elif total_inputs[-1] == "undo" or "redo":
          deletedwords.append(k)
          (master_line.pop)
          False
        else:
          deletedwords.append(q)
          (master_line.pop)
          False
    elif (c=="undo"):
      q = total_inputs[-1]
      while True:
        total_inputs.append("undo")
        if (q == "redo"):
          k = 1
          p = 0
          while True:
            if total_inputs[-k] == "undo" or "redo":
              k = k+1
              continue
            else: 
              p = total_inputs[-k]
              q = 0
              False
        elif (q or p == "d"):
          master_line.append(deletedwords[-1])[-1]
        else:
          if total_inputs[-1] == "undo" or "redo":
            deletedwords.append(k)
            (master_line.pop)
          else:
            deletedwords.append(q)
            (master_line.pop)
  False
line_editor