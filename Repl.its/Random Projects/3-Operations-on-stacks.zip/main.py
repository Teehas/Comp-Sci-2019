#JUST RUN TO TEST!
#enter 3 values, it will then swap the first and last, and finally give you the option to roll
#program will repeat for second method

class Stack:
    
    def __init__(self):
        '''A new empty stack'''
        self.items = []
    
    def push(self):
        '''Make o the new top item in this Stack.'''
        o = input('enter a value to append')
        self.items.append(o)
        
    def pop(self):
        '''Remove and return the top item.'''
        return self.items.pop()
    
    def peek(self):
        '''Return the top item.'''
        return self.items[-1]
    
    def isEmpty(self):
        '''Return whether this stack is empty.'''   
        return self.items == []
    
    def size(self):
        '''Return the number of items in this stack.'''
        return len(self.items)
#---------------My Code------------------------#
    def swap (self):
      print('before', self.items)
      a = self.items.pop(0)
      b = self.items.pop()
      self.items.insert(0, b)
      self.items.append(a)
      print('after',self.items)
    def roll (self):
      n = int(input('input a value for n to roll'))
      try:
        print('before', self.items)
        temp = self.items.pop(n-1)
        self.items.insert(0,temp)
        print('after', self.items)
      except IndexError: print('index out of range')
      except ValueError: print('incorrect input')
#---------------------------------------#

class UpStack:

    def __init__(self):
        '''A new empty stack'''
        self.stack = []
    
    def push(self,):
        '''Make o the new top item in this Stack.'''
        o = input('enter a value to push')
        self.stack.insert(0, o)
        
    def pop(self):
        '''Remove and return the top item.'''
        return self.stack.pop(0)
    
    def peek(self):
        '''Return the top item.'''
        return self.stack[0]
    
    def isEmpty(self):
        '''Return whether this stack is empty.'''   # This is like a Javadoc comment.
        return self.stack == []
    
    def size(self):
        '''Return the number of items in this stack.'''
        return len(self.stack)
#----------------Same Code as above class---------------------#
    def swap (self):
      print('before', self.stack)
      a = self.stack.pop(0)
      b = self.stack.pop()
      self.stack.insert(0, b)
      self.stack.append(a)
      print('after',self.stack)
    def roll (self):
      n = int(input('input a value for n to roll'))
      try:
        print('before', self.stack)
        temp = self.stack.pop(n-1)
        self.stack.insert(0,temp)
        print('after', self.stack)
      except IndexError: print('index out of range')
      except ValueError: print('incorrect input')
#--------------------Driver Code------------------#

print('--------------UPSTACK------------')
x = UpStack()
x.push()
x.push()
x.push()
x.swap()
x.roll()
print('--------------------STACK---------------')
y = Stack()
y.push()
y.push()
y.push()
y.swap()
y.roll()