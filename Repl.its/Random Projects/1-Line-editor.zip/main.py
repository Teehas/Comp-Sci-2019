# For test case, feel free to pick any 3 things to add to the list, i tested with a, b and c. Scroll to the bottom to see the inputs I chose to showcase all the methods but they can be switched to any order.

class line:
  master_line = []
  total_inputs = []
  deleted_words = []
  deleted_words_index = []

#---------------------------
  def add(self,):
    word = str(input("enter a word"))
    self.master_line.append((word)[-1])
    self.total_inputs.append("w")
    print (self.master_line)
#---------------------------
  def d(self):
    i = int(input("which word would you like to remove"))-1
    self.deleted_words.append(self.master_line[i])
    self.deleted_words_index.insert(0, i)
    self.total_inputs.append("d")
    self.master_line.pop(i)
    print (self.master_line)
#---------------------------
  def undo(self):
    if(self.total_inputs[-1] == "d"): self.undo_d()
    elif(self.total_inputs[-1] == "undo" or self.total_inputs[-1] == "redo" or self.total_inputs[-1] == "undo_d" or self.total_inputs[-1] == "undo_w"):
      n = -2
      k = self.total_inputs[n]
      while True:
        if (k == "d" or k == "undo_d"):
          self.undo_d()
          break
        elif (k == "undo" or k == "redo"):
          k = self.total_inputs[n-1]
          continue
        else: self.undo_w(); break
    elif(self.total_inputs[-1] == IndexError):
      print("can not undo from an empty list, please try again")
      self.undo()
    else: self.undo_w()
#---------------------------
  def undo_d(self):
    self.master_line.insert(self.deleted_words_index[0], self.deleted_words[-1])
#    self.deleted_words_index.pop(0)
    self.deleted_words.pop()
    self.total_inputs.append("undo_d")
    print (self.master_line)
#---------------------------
  def undo_w(self):
    self.deleted_words.append((self.master_line[-1])[-1])
    self.master_line.pop()
    self.total_inputs.append("undo_w")
    print (self.master_line)
#--------------------------
  def redo(self):
    if (self.total_inputs[-1] == ("undo_d")):
      i = self.deleted_words_index[0]
      self.deleted_words.append(self.master_line[i])
      self.deleted_words_index.append(i)
      self.total_inputs.append("redo")
      self.master_line.pop(i)
      print (self.master_line)
    elif (self.total_inputs[-1] == ("undo_w")):
      self.add()
    else: print("you can only redo an undo")\
#--------------------------------
#command section
x = line()
x.add()
x.add()
x.add()
x.d()
x.undo()
x.redo()
x.undo()
x.redo()