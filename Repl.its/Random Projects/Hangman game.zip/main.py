x = int(input("Welcome to hangman! Select 1 to enter a word, select 2 to begin the game, select 3 to exit" ))
displaylist = []
#-------------------------------------------

if (x == 1):
    word = str(input("Enter a word for the game in lowercase letters"))
    List = list(word)

for z in range(len(List)):
    displaylist.append("*")
x = int(
    input(
        "Welcome to hangman! Select 1 to enter a word, select 2 to begin the game, select 3 to exit"
    ))
#----------------------------------------------

if (x == 2):
  i = True
  lives = 6
  letters = []
  progress = [' ']
  count = 0
  print("word", List)
  while (i == True):
    guess = str(input("enter a single lowercase letter as your guess"))

    print("current lives, ", lives)
    print("letters guessed", letters)
    print(displaylist)
    if ((guess in letters)):
        print("You already guessed that! Guess again.")
    elif(guess == ''):
      print ('you can not enter a space as a letter.')
    elif (guess in List):
      progress.append(guess)
      for u in range(len(List)):
        if (guess == List[u]):
          displaylist.pop(u)
          displaylist.insert(u,guess)
    else:
        print("GUESS WAS INCORRECT")
        lives = lives - 1
    if (guess in letters):
        pass
    else:
        letters.append(guess)
    if (lives == 0):
        print("You are out of lives, thanks for playing!")
        break
    if ("*" not in displaylist):
        print("CONGRATULATIONS, YOU WIN")
        break
  exit
#-------------------------------------------
if (x == 3):
    print("Thanks for playing!")
    exit
