"""
def sum1(n):
  x = 0
  for i in range(n):
    x = x+(i+1)
  print(x)

sum1(4)
"""
"""
def sum2(n):
  x = 0
  for i in range(n):
    i = i+1
    x = x+((i)*(i)*(i))
  print(x)

sum2(3)
"""
"""
def sum3(n):
  x = 0
  for i in range(n):
    i = i+1
    x = x+((3-2*(i))*(3-2*(i)))
  print(x)

sum3(100)
"""

