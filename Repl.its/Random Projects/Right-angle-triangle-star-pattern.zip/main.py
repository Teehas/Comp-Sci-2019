x = int(input("enter size of triangle"))
#rows
for y in range(1,x+1):
  for i in range (1,y+1):
    print ("*", end="")
  print ()

#count
#z = range (x,0,-1)
#print (z)
#for z in range (x,0,-1):
 # print (z+)
  #print ((x**2)/2)

