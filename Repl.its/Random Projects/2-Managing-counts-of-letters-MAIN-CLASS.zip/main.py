class main:
  master_list = []
  d = {}
  d2 = {}
  word = ""
  def __init__(self,):
    self.word = str(input("Please enter a string"))
    self.word = self.word.lower()
    self.master_list.append(list(self.word))
    for char in set(self.word):
      self.d[char]=self.word.count(char)
    print(self.master_list)
    print(self.d)
#-----------------------------------------------------#

#------------------------------
  def get(self):
    x = str(input("enter the character to search for"))
    x = x.lower()
    if (x in self.word): print(self.word.count(x), "elements in the list")
    else: print("This element does not exist in the list")
#------------------------------
  def set_(self):
    character = input("enter the value to change")
    value = input("enter the new value to set this character to")
    self.d[character]=value
    print(self.d)
#------------------------------
  def size(self):
    y = sum(self.d.values())
    print("there are", y, "letters in the word")
#------------------------------
  def isempty(self):
    if (len(self.d) == 0): print("list is empty")
    else: print("list is not empty")
#------------------------------
  def __str__(self): 
    print(sorted(self.master_list[0]))
    if (len(self.master_list) > 1): print(sorted(self.master_list[1]))
#------------------------------  
  def add(self):
    word_a = main()
#------------------------------
  def subtract(self):
    word_s = input("enter a word you would like to subtract from the list")
    try:
      for char in set(word_s): self.d[char]-=word_s.count(char)
      print(self.d)
    except KeyError: print('you cant subtract letters that arent there!')
#All Methods
x = main()
x.add()
x.__str__()
x.size()
x.set_()
x.get()
x.isempty()
x.subtract()