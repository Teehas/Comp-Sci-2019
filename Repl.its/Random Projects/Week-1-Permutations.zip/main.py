p_list = []
while True:
  word = int(input("enter a singular of words or numbers to permutate. To finish the list enter a blank space."))
  if (word == 0):
    break
    print(p_list)
  else:
    p_list.append(word)
    print(p_list)
n = len(p_list)
for x in range(n):
  z = n*n-1
list_copy = p_list
#z now equals the number of possible permutations
for d in range(z):
  g = p_list[-1]
  j = p_list[0]
  for y in range(n):
    print (p_list)
    if (g != p_list[0]):
      p_list.append(g)[g-1]
      g = p_list[g-1]
    else:
      p_list = list_copy
      g = p_list[-1]
      if p_list[g-1] != p_list[0]: g = p_list[g-1]
  p_list = list_copy
  p_list.append(p_list[0])[-1]
  p_list.remove[0]


