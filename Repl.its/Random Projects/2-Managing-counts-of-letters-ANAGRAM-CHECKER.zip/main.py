class main:
  d = {}
  d2 = {}
  word = ""
  word_a = ""
  def __init__(self,):
    self.word = str(input("Please enter a string"))
    self.word = self.word.lower()
    for char in set(self.word):
      self.d[char]=self.word.count(char)
    self.word_a = input('please enter a string')
    for char in set(self.word_a):
      self.d2[char]=self.word_a.count(char)
    if (self.d == self.d2): print("words are anagrams!")
    else: print("words are not anagrams :(")
#-----------------------------------------------------#
x = main()