def square_root(n):
  for i in range(n):
    if (i*i == n):
      print(i)
square_root(1048576)
