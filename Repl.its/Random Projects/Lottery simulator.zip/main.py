usernumbers = []
drawnumbers = []
templottery = []
bonus = 1
game = 1
count = 0

def choosenum():
  while ((len(usernumbers)<=5)):
    userin = int(input("please enter 6 different numbers from 1-49 one by one"))
    if (userin in usernumbers):
      print("please enter a different value that is not already in the list")
      print(usernumbers)
    elif(userin > 49) or (userin < 1):
      print("inputs must be integers from 1-49")
      print(usernumbers)
    else:
      usernumbers.append(userin)
      print(usernumbers)

def luckyd():
  import random
  while ((len(drawnumbers)) <= 6):
    randnum = (random.randint(1,49))
    if (randnum in drawnumbers):
      pass
    else:
      drawnumbers.append(randnum)

def rundraw():
  import random
  bonus = (random.randint(1,49))
  for index in usernumbers :
    if usernumbers in drawnumbers:
      usernumbers.append(templottery)
  if (len(templottery) < 3):
    print("sorry you didn't win anything, try again")
  elif (len(templottery) == 3):
    print("CONGRATULATIONS! You won $10")
  elif (len(templottery) == 4):
    print("CONGRATULATIONS! You won $70!")
  elif (len(templottery) == 5):
    for i in usernumbers:
        if (bonus in usernumbers):
          print ("CONGRATULATIONS! You won $100,000")
        else:
          print("CONGRATULATIONS! You won $1000!")
  elif (len(templottery) == 6):
    print("JACKPOT! You won $3,000,000!")
  print ("Your numbers: ", usernumbers)
  print ("winning numbers: ", drawnumbers)
  print ("Matches:", templottery)

def runsim():
  count = 0
  while (len(templottery) != 6):
    import random
    while ((len(drawnumbers)) <= 6):
      randnum = (random.randint(1,49))
      if (randnum in drawnumbers):
        pass
      else:
        drawnumbers.append(randnum)

      for index in usernumbers :
        if usernumbers in drawnumbers:
          usernumbers.append(templottery)
        if (len(templottery) == 6):
         print("JACKPOT! You won $3,000,000!")
        else:
          pass
    count = count + 1
  years = count/52.1429
  print ("It took", count, "number of tries to win the jackpot.")
  print ("This translates to", count, "weeks,  ", years, "number of years, ", "and $", count, "spent on tickets assuming each ticket to cost $1")


def menu():
  while (game == 1):
    print("Welcome to lottery! \n please select a number to begin \n select 1 to choose number \n select 2 to start lucky dip \n select 3 to run draw \n select 4 to run simulation \n select 5 to exit \n \n **NOTE: ONE AND TWO MUST BE COMPLETED TO RUN THREE AND FOUR" )
    x = int(input(" \n Choose a number:"))
    if (x == 1):
      choosenum()
    if (x == 2):
      luckyd()
    if (x == 3):
      rundraw()
    elif (x == 4):
      runsim()
    elif (x == 5): {
      print("Thanks for playing!")
    }

menu()