
def factorial(n):
  for x in range(n-1):
    n = n*(x+1)
    print (n)  
factorial(3)


""""
def euler(a, b):
  while True:
    for x in range(a):
      a = a*(a-1)
    for y in range(b):
      b = b*(b-1)
    if (1/a > 1/b):
      e = (1/a)+(1/b)
      a = a+2
      b = b+2
      print(e)
    
  False

euler(2,3)
"""